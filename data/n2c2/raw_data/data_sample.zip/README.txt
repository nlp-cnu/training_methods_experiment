This file contains sample texts and annotations for the 2018 n2c2 shared task
Track 2: Adverse Drug Events

These files were annotated in BRAT; if you would like to view the texts and
the annotations together, you will need to install BRAT locally, and use the
annotation.conf file to configure BRAT.

Instructions for installation and configuration can be found here:
http://brat.nlplab.org/installation.html
http://brat.nlplab.org/configuration.html

Any technical difficulties with BRAT should be report to the official GitHub page
https://github.com/nlplab/brat/issues
